print ("witaj swiecie")
