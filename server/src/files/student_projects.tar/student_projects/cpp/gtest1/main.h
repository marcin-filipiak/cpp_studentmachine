// moj_program.h
#ifndef MOJ_PROGRAM_H
#define MOJ_PROGRAM_H

#include "functions.cpp"


#endif // MOJ_PROGRAM_H

