#include <iostream>
#include "functions.cpp"

using namespace std;

int main() {
    std::cout << "sumowanie ";
    std::cout << suma(5, 1) << std::endl;
    return 0;
}

