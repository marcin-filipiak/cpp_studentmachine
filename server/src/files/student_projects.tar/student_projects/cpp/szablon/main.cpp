#include <iostream>

using namespace std;

int main(){
	cout<<"witaj swiecie"<<endl;
	return 0;
}
