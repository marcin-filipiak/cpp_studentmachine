#!/bin/sh

chmod +x ~/student_projects/python/szablon/main.py
chmod +x ~/student_projects/cpp/szablon/kompiluj.sh
